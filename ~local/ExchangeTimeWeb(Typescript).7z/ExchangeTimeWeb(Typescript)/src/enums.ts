export enum BarType 
{
  S,
  M,
  L,
  Weekend,
  Holiday
}
